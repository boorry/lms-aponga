## Mission
- Mission ID:
- Phase:
- Related issue/decision:

## Objective
<!-- What is being changed and why? -->

## References
- Normative references:
- API/model/security impact:

## Validation
- [ ] lint
- [ ] typecheck
- [ ] tests
- [ ] build
- [ ] E2E if applicable
- [ ] invariants reviewed
- [ ] permissions reviewed
- [ ] migration reviewed if applicable

## Change control
- [ ] No architectural change
- [ ] Or architectural change documented and approved

## Documentation / tracking
- [ ] DONE.md updated
- [ ] BLOCKERS.md updated if needed
- [ ] DECISIONS_DEV.md updated if needed
- [ ] API/reference documentation updated if behavior changed
